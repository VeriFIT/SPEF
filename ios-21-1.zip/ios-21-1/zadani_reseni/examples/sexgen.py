#!/usr/bin/env python3
#
# Stock EXchange log GENerator

import argparse
import csv
import datetime
import random
import sys
import uuid


# default screener containing tickers, names, prices, etc.
DEFAULT_SCREENER = "nasdaq_screener_1614080048748.csv"

# list of companies with stock information
companies = []

# the timestamp of the last generated item
last_timestamp = None


###########################################
def random_date(start, end=None):
    """Generate a random datetime between `start` and `end`"""
    if not end:
        end = start + datetime.timedelta(minutes=10)

    return start + datetime.timedelta(
        # Get a random amount of seconds between `start` and `end`
        seconds=random.randint(0, int((end - start).total_seconds())),
    )


###########################################
def gen_item():
    """gen_item() -> [str]

Generates a random log item.
"""
    global last_timestamp
    item = dict()

    last_timestamp = random_date(last_timestamp)
    item['time'] = str(last_timestamp)

    comp = random.choice(companies)
    item['ticker'] = comp['Symbol']

    price = comp['Last Sale']
    price = price.replace('$', '')
    price = float(price)
    price *= random.uniform(0.9, 1.1)
    item['unit price'] = "{:.2f}".format(price)

    order_type = random.choice(['buy', 'sell'])
    item['type'] = order_type

    item['currency'] = 'USD'

    vol = random.randrange(1, 10000)
    item['volume'] = str(vol)

    id = uuid.uuid1(clock_seq=random.randrange(1, 10000))
    item['id'] = str(id)

    return item


###########################################
def load_companies(filename, take):
    """load_companies(filename, take) -> ()

Loads companies and takes top X wrt. market capitalization.
"""
    global companies
    with open(filename, 'r') as fd:
        reader = csv.DictReader(
            fd, delimiter=',', quotechar='"',
            quoting=csv.QUOTE_MINIMAL)
        for row in reader:
           companies.append(row)

    companies.sort(
        key=(lambda x: float(x['Market Cap']) if x['Market Cap'] else 0),
        reverse=True)

    companies = companies[:take]


###########################################
def main(args):
    """main(args) -> ()

Main entry point.
"""
    load_companies(args.screener, args.take)
    # print(str(companies))

    # initialize last_datetime
    global last_timestamp
    last_timestamp = random_date(
        datetime.datetime.strptime('1/1/21 06:00:00', '%d/%m/%y %H:%M:%S'),
        datetime.datetime.strptime('15/12/21 10:00:00', '%d/%m/%y %H:%M:%S'))

    fieldnames = ['time', 'ticker', 'type', 'unit price', 'currency', 'volume', 'id']
    writer = csv.DictWriter(
        sys.stdout, fieldnames=fieldnames,
        delimiter=';', quotechar='"', quoting=csv.QUOTE_MINIMAL,
        lineterminator='\n')
    # writer.writeheader()
    for i in range(args.records):
        item = gen_item()
        writer.writerow(item)




###########################################
if __name__ == '__main__':
    parser = argparse.ArgumentParser(
                description="sexgen - "
                "Stock EXchange log GENerator")
    parser.add_argument('-s', '--screener', type=str, default=DEFAULT_SCREENER,
                        help='Screener (default: %(default)s)')
    parser.add_argument('-t', '--take', metavar='NUM', type=int, default=20,
                        help='Take top NUM companies wrt. market capitalization (default: %(default)s)')
    parser.add_argument('-r', '--records', metavar='NUM', type=int, default=100,
                        help='Generate a log with NUM records (default: %(default)s)')

    args = parser.parse_args()
    main(args)
