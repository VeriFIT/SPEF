# Stock EXchange log GENerator

Generator of examples.

* `nasdaq_screener_1614080048748.csv`: downloaded from [NASDAQ list](https://www.nasdaq.com/market-activity/stocks/screener)
