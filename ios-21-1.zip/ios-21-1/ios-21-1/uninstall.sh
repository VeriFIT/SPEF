#!/bin/bash
SANDBOXUSER=sandbox
SANDBOXLOCK=/usr/local/share/studenttest/lock
TESTSDIR=/usr/local/share/studenttest/ios-21-1

die()
{
    echo error: "$@"
    exit 1
}

if [ -z "$SANDBOXUSER" ]; then
    die "TESTUSER a SANDBOXUSER nenastaveny"
fi

if [ `id -u` != 0 ]; then
    die "must be run as root"
fi

userdel -r $SANDBOXUSER
groupdel $SANDBOXUSER
rm /etc/sudoers.d/$SANDBOXUSER

# pripadna kontrola, ze TESTSDIR je nastaven spravne
if [[ -f $TESTSDIR/tst ]]; then
    rm -r $TESTSDIR
fi

echo "Mam smazat i adresare pro zamykani a jine testy?"
echo "  $SANDBOXLOCK"
echo "  $(dirname $TESTSDIR)"
echo -n "Mohou byt totiz aktualne pouzivane jinymi testovacimi sadami. [Na] "
read ans
if [[ "$ans" = a ]]; then
    rmdir $SANDBOXLOCK
    rmdir $(dirname $TESTSDIR)
fi
