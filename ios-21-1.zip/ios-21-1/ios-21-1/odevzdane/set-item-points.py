#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# 
# Automaticke nahravani bodu do informacniho systemu FIT.
# Vyuziva XML-RPC ISu (Lampa, 2012)
#
# Ales Smrcka, 2013
#

from datetime import datetime
import xmlrpc.client
import sys
from getpass import getpass
from os import getenv, getlogin, chmod
VERBOSE=1
DEBUG=0

# Nasledujici udaje zmenit jednou za rok
predmet='IOS'
rok=2020
semestr='L'
# Varianta je cislo parametru id v URL terminu, napr. 37728 pro
# https://wis.fit.vutbr.cz/FIT/db/vyuka/ucitel/item-stud.php?id=37728
varianta_terminu = 83881 # IOS 2020/21 1. projekt
komentar='Podrobnosti k hodnocení najdete v příloze mailu.'

# Pro nezobrazovani uspesne nahranych polozek odkomentovat nasledujici radek 
#VERBOSE=0

# Prihlasovaci udaje do WISu (bez toho to nejde):
# Konfiguracni soubor s prihlasovacimi udaji. Pokud soubor neexistuje, ulozi se
# do nej udaje ziskane interaktivne od uzivatele. Pokud je credentials_file 
# neprazdny retezec, ulozi se jmeno a heslo do tohoto souboru. Pri dalsim
# spusteni se prihlasovaci udaje ziskaji z tohoto souboru. V pripade, ze je
# credentials_file prazdny retezec, ziskavaji se udaje z wislogin a wisheslo.
# Pokud i ty jsou prazdne, budou se udaje pri kazdem spusteni ziskavat
# interaktivne od uzivatele.
credentials_file = getenv("HOME") + '/.wiscredentials.cfg'
# Nastaveni obou nasledujicich udaju vzdy obchazi credentials_file.
wislogin=''
wisheslo=''


###########
# BEGIN: srandicky, obezlicky
###########
def hilite(string, status, bold=0):
    'http://stackoverflow.com/questions/2330245/'
    if sys.stdout.isatty():
        attr = []
        if status:
            attr.append('32')
        else:
            attr.append('31')
        if bold:
            attr.append('1')
        return '\x1b[%sm%s\x1b[0m' % (';'.join(attr), string)
    else:
        return text
###########
# END: srandicky, obezlicky
###########

def set_item_points(student, body):
    "item: [xlogin, bodu]"
    global komentar
    host = 'wis.fit.vutbr.cz'
    handler = '/FIT/db/vyuka/ucitel/course-item-xml.php'
    try:
        server = xmlrpc.client.ServerProxy("https://%s:%s@%s%s" % \
                (wislogin, wisheslo, host, handler))
    except Exception as e:
        print('error: xml-rpc: %s' % e)
        sys.exit(3)
    datum = datetime.now().strftime("%F")

    try:
        result = server.courses.set_item_points(predmet, rok, semestr,
            varianta_terminu, student, body, komentar, wislogin, datum, 
            int(not DEBUG))
        if VERBOSE:
            try:
                total = server.courses.get_total_points(predmet, rok,
                        semestr, student)
                print('ok:    %s (%db, %sb celkem z predmetu), %s' % (student, body, \
                        hilite(str(total), int(total)>=50),
                        hilite(result, result.startswith('OK'))))
            except xmlrpc.client.Fault as err:
                print('error get_points: %s, %s' % (student, err))
                return 0
        return 1
    except xmlrpc.client.Fault as err:
        print('error: %s, %s' % (student, err))
        return 0
    except Exception as e:
        print('error: xml-rpc: %s' % e)
        sys.exit(3)

def assure_credentials():
    """zaridi nacteni prihlasovacich udaju (ze souboru nebo z uzivatele)
    ulozi do souboru credentials_file nebo ne, podle toho, jestli je jeho
    jmeno nastaveno"""
    def user_input():
        global wislogin
        global wisheslo
        if not wislogin:
            wislogin = input('FIT IS login: ')
            if not wislogin:
                print('exiting')
                sys.exit(1)
        if not wisheslo:
            if not wisheslo:
                wisheslo = getpass('IS FIT heslo: ')
            if not wisheslo:
                print('exiting')
                sys.exit(1)
    def load_config():
        global wislogin
        global wisheslo
        fin = open(credentials_file)
        config = fin.read().splitlines()
        fin.close()
        config = dict([l.split('=') for l in config])
        wislogin = config['wislogin']
        wisheslo = config['wispasswd']
    def save_config():
        try:
            fout = open(credentials_file, 'w')
            chmod(credentials_file, 0o600)
            fout.write('wislogin=%s\nwispasswd=%s\n' % \
                    (wislogin, wisheslo))
            fout.close()
            print('WIS credentials saved to %s' % credentials_file)
        except Exception as e:
            print('error: unable to open %s for writing' % \
                    credentials_file)
            sys.exit(1)

    if not wislogin or not wisheslo:
        if credentials_file:
            try:
                load_config()
            except:
                print('error: unable to read %s' % credentials_file)
                user_input()
                save_config()
        else:
            user_input()
    else:
        if credentials_file:
            save_config()

def die_help():
    print('usage: %s {set|debug} xlogin body' % sys.argv[0])
    print('commands:')
    print('    set     set the given points in wis')
    print('    debug   debug mode, do not set the points')
    sys.exit(1)


###############################################################################
# MAIN
if __name__ == "__main__":
    try:
        if len(sys.argv) < 4:
            die_help()
        if sys.argv[1] == 'set':
            DEBUG=0
        elif sys.argv[1] == 'debug':
            DEBUG=1
        else:
            die_help()
        xlogin = sys.argv[2]
        try:
            points = float(sys.argv[3])
        except:
            print('err')
            die_help()
        assure_credentials()
        set_item_points(xlogin, points)
    except KeyboardInterrupt:
        pass
