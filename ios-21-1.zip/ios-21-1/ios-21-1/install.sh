#!/bin/bash
SANDBOXUSER=sandbox
TESTSDIR=/usr/local/share/studenttest
SANDBOXLOCK=$TESTSDIR/lock
USER=$SUDO_USER

die()
{
    echo error: "$@"
    exit 1
}

if [ `id -u` != 0 ]; then
    if [ -f tests/src/Makefile ]; then
        echo Cistim a prekladam test doubles
        echo ===============================
        make -C tests/src clean
        make -C tests/src || die "Nepovedlo se prelozit test doubles"
        echo ===============================
    fi
    echo "Pro dalsi instalaci musis byt root. Spoustim se pres sudo ..."
    echo sudo $0 "$@"
    sudo $0 "$@"
    exit 0
fi

type realpath &>/dev/null || 
    die "Nemas utilitu realpath(1), nainstaluj (balik coreutils?)"

cd $(dirname $(realpath $0))

if [ -z "$USER" ]; then
    echo -n "Jaky je tvuj login jako vyucujiciho?: "
    read USER
    [ -z "$USER" ] && exit 0
fi

echo Kontroluji existenci testovaciho uzivatele $SANDBOXUSER ...
if ! id $SANDBOXUSER &>/dev/null; then
    echo "Uzivatel '$SANDBOXUSER' neexistuje, vytvarim ..."
    useradd -d /home/$SANDBOXUSER -U $SANDBOXUSER || die "useradd $SANDBOXUSER"
    
    echo "  - mazu domovsky adresar /home/$SANDBOXUSER (skeleton a jine)"
    rm -rf /home/$SANDBOXUSER

    echo "  - pridavam uzivatele '$USER' do skupiny '$SANDBOXUSER'"
    usermod -aG $SANDBOXUSER $USER || die "usermod2 $USER"
    echo "    Aby to melo efekt, `tput bold`muze byt treba`tput sgr0` se prihlasit znovu."

    echo "  - vytvarim novy, prazdny home: /home/$SANDBOXUSER"
    mkdir /home/$SANDBOXUSER
    chown $SANDBOXUSER.$SANDBOXUSER /home/$SANDBOXUSER
    chmod 770 /home/$SANDBOXUSER
fi

DIR=$(basename $(pwd))

echo "Vytvarim adresar pro zamky $SANDBOXLOCK ..."
mkdir -p $SANDBOXLOCK 2>/dev/null
chown $USER.$SANDBOXUSER $SANDBOXLOCK
chmod 2775 $SANDBOXLOCK

echo "Vytvarim adresar s testy $TESTSDIR ..."
mkdir -p $TESTSDIR 2>/dev/null
chmod 755 $TESTSDIR
rm -rf $TESTSDIR/$DIR 2>/dev/null
rsync -a \
    --exclude=.svn --exclude=.git \
    --delete --delete-excluded tests/ $TESTSDIR/$DIR/
chmod -R ga+rX $TESTSDIR/$DIR

echo "Vytvarim prazdny adresar /home/$SANDBOXUSER/$DIR ..."
rm -rf /home/$SANDBOXUSER/$DIR &>/dev/null
mkdir /home/$SANDBOXUSER/$DIR
chown $SANDBOXUSER.$SANDBOXUSER /home/$SANDBOXUSER/$DIR
chmod 2775 /home/$SANDBOXUSER/$DIR

echo "Upravuji soubor sandbox.config podle aktualniho nastaveni ..."
cat >sandbox.config <<EOF
SANDBOXUSER=$SANDBOXUSER
SANDBOXDIR=/home/$SANDBOXUSER/$DIR
SANDBOXLOCK=$SANDBOXLOCK
TESTSDIR=$TESTSDIR/$DIR
EOF
chown $USER sandbox.config

echo "Nastavuji sudo (uzivatel $USER muze cokoliv jako $SANDBOXUSER) ..."
[ -d /etc/sudoers.d ] || die "/etc/sudoers.d does not exists"

cat >/etc/sudoers.d/$SANDBOXUSER <<EOF
$USER ALL=($SANDBOXUSER) NOPASSWD: ALL
EOF
chmod 440 /etc/sudoers.d/$SANDBOXUSER

echo "Upravuji soubor uninstall.sh s informacemi o aktualnim nastavenim ..."
sed -i "
s#^SANDBOXUSER=.*#SANDBOXUSER=$SANDBOXUSER#
s#^SANDBOXLOCK=.*#SANDBOXLOCK=$SANDBOXLOCK#
s#^TESTSDIR=.*#TESTSDIR=$TESTSDIR/$DIR#" ./uninstall.sh

echo "Nastavuji prava pro menu pro Midnight Commander ..."
chmod 644 odevzdane/.mc.menu odevzdane/.xlogin.mc.menu
