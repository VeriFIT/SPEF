# TESTY Z LOKALNI KOPIE

1. Stazeni a instalace (

```
    $ git clone https://.../ios/ios-21-1
    $ cd ios-21-1
    $ sudo ./install.sh
```

2. A dal bud rucne z shellu:

```
    $ . include_me    (tady jde hlavne o nastaveni PATH k testovacim zkratkam)
        t     spusteno v adresari loginu provede celou testovaci sadu
        n     s nejakym parametrem prida komentar k rucnimu hodnoceni
        s     secte vsechny body ze vsech testu (napr. po rucni uprave
              hodnoceni)
        tst   wrapper testovaciho skriptu (prostredi) ios/tests/tst
```

3. nebo pomoci Midnight Commanderu:

```
    $ cd odevzdane
    $ mc
```

4. Nasledne vyvolat menu F2 (nad adresarem studenta se toho v menu objevi vic)

# POSTUP

body 1-3 zaberou chvili, bod 4 je na dlouho

1. Do ios/ios-21-1/odevzdane rozbalit bobanky (kazdy bobanek ma svuj login adresar a v nem login.zip odevzdany soubor).
2. Nastavit si prostredi:

```
    $ cd ios/ios-21-1
    $ . include_me
```

3. Bobanky sjet automaticky:

```
    $ cd ios/ios-21-1/odevzdane
    $ ./0-rozbal; ./1-prejmenuj
    $ ./2-testall
```

4. Hodnoceni kazdeho bobanka zkontrolovat rucne a upravovat bud pomoci menu v Midnight Commanderu (F2), nebo pomoci prikazu `n`.
5. Potvrdit s ostatnimi vyucujicimi, ze vysledek hodnoceni je ok.
6. Zabalit hodnoceni pro kazdeho bobanka na odeslani postou (hodnoceni.tgz)
7. Vzhledem k tomu, ze meli neco balit a to, co vytvorili, se jim bude posilat, chce to jeste kontrolu, ze v archivech v jednotlivych testech nemaji nejake veci, co jim nenalezi (napr. reseni nejakeho jineho loginu). Toto (pokud to chce resit) si kazdy resi po svem.
8. Odeslat kazdemu bobankovi soubor hodnoceni.tgz. Napsat info, jak se bude patchovat:
   * aplikace patche pouze jednou za projekt.
   * patch pouze na souborech, ktere odevzdali (tedy ne na tech, ktere vyucujici rucne upravil, pokud upravil).
   * veskere rucni plusove skore pujde do kytek (slouzilo to totiz jako kompenzace za prilis striktni testy a tim patchem maji chybu odstranit).
   * bude strzeno skore odpovidajici slozitosti patche.
   * bude to spravedlive, tj. pokud patch opravuje jen jeden pripad, bude strzeno prave tolik, za kolik je dany pripad hodnocen ==> path ma vyhodu pouze pro jednoduche opravy, ktere zlepsi uspesnost vice automatickych testu.

# PARALELNI SPOUSTENI TESTU

Pokud mate vic procesoru/jader, tak se testy spousti paralelne. Pokud by to delalo nejakou neplechu, staci nastavit promennou NOPAR:

```
    $ cd xlogin00
    $ NOPAR=y t
```

# NAVOD KE CTENI SOUBORU `hodnoceni`

Radky v souboru 'hodnoceni' jsou techto druhu:

1. radky informujici o celkovem bodovem hodnoceni/skore (prvni a posledni radky):

```
    13:celkove score
    9:celkem bodu za projekt
```

2. radky informujici o vysledku jednoho testu (zacinaji cislem):

```
    1:ok:foo vola bar
    ^ ^  ^
    | |  +- kratky popis testu
    | +---- vysledek testu (ok nebo nazev testu, ktery selhal)
    +------ score za test
```

3. radky komentujici vysledek (zacinaji mrizkou):

```
    # diff -u stdout.ref stdout
    #   --- stdout.ref      2012-03-26 17:42:41.344279575 +0200
    #   +++ stdout  2012-03-26 17:42:41.313279191 +0200
    #   @@ -0,0 +1 @@
    #   -vysledek mel byt 0
    #   +vysledek byl ale 1
```

4. uzivatelem (vyucujicim) rucne upravene bodove hodnoceni, napr.

```
    -2:nepouziva POSIXove utility
```

Pokud nejaky test selhal, podrobnosti o testu jsou v jeho adresari (adresar testu nese jeho jmeno). V adresari jsou soubory:

* `spusteni` - jak byl program spusten (parametry a presmerovani)
* `stdin` - s jakym vstupem byl program spusten (kdyz soubor chybi, tak vstupem byl soubor /dev/null)
* `stdout` - co testovany program vypsal na stdout
* `stderr` - co testovany program vypsal na stderr
* `errcode` - s jakym navratovym kodem byl program ukoncen
* `hodnoceni-auto` - vystup z automatickeho hodnoceni testu
* ...a pripadne dalsi soubory specificke danemu testu.