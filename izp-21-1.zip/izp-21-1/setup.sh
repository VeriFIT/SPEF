#!/bin/sh

chmod 600 .mc.menu
chmod +x ?-* 4a-* dowisu.py prepare-studtbl.sh t setup.sh
