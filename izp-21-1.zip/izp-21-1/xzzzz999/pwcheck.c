/**
 * IZP 2021
 * project #1: sample solution
 * author: iandri
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

// max buffer length = max line length + 1
#define MAX_LINE_LENGTH     100
#define MAX_STRING_LENGTH   MAX_LINE_LENGTH+1

// ASCII-range of special characters
#define SPECIAL_LOWER 33
#define SPECIAL_UPPER 126

// distinguishable classes for password characters
enum CharacterClass {class_lower, class_upper, class_digit, class_special, class_other};

// number of ASCII-characters
#define ASCII_CHARACTERS 127



/* Character operations. */

/** @return true if c is a digit */
bool char_isdigit(char c) {
    return c >= '0' && c <= '9';
}

/** @return true if c is a lowercase letter */
bool char_islower(char c) {
    return c >= 'a' && c <= 'z';
}

/** @return true if c is an uppercase letter */
bool char_isupper(char c) {
    return c >= 'A' && c <= 'Z';
}

/** @return true if a non-letter and non-digit c is a special character. */
bool char_isspecial(char c) {
    return c >= SPECIAL_LOWER && c <= SPECIAL_UPPER;
}



/* String operations. */

/** @return length of string */
unsigned string_length(const char *str) {
    unsigned len = 0;
    while(str[len] != '\0') {
        len++;
    }
    return len;
}

/** @return true if all characters in str are digits */
bool string_isdigit(const char *str) {
    for(unsigned pos = 0; str[pos] != '\0'; pos++) {
        if(!char_isdigit(str[pos])) {
            return false;
        }
    }
    return true;
}

/**
 * Check if src is a sequence of digits.
 * If so, interpret it as an unsigned integer.
 * @param error_flag set to true if the input string is invalid
 * @return parsed number
 */
unsigned string_to_unsigned(const char *src, bool *error_flag) {
    if(!string_isdigit(src) || src[0] == '\0') {
        *error_flag = true;
        return 0;
    }
    return strtoul(src,NULL,0);
}

/** @return true if x and y are equal strings */
bool string_equal(const char *x, const char *y) {
    unsigned pos = 0;
    for(pos = 0; x[pos] != '\0' && y[pos] != '\0'; pos++) {
        if(x[pos] != y[pos]) {
            return false;
        }
    }
    return x[pos] == y[pos];
}

/** @return number of repeating characters at the beginning of str. */
unsigned same_character_sequence(const char *str) {
    const char *ptr = str;
    while(*ptr != '\0' && *ptr == *str) {
        ptr++;
    }
    return (ptr-str)/sizeof(*str);
}

/**
 * @return true if the first {@code limit} characters of two strings are
 * equal
 */
bool string_equal_limited(const char *x, const char *y, unsigned limit) {
    unsigned pos = 0;
    for(pos = 0; pos < limit; pos++) {
        if(x[pos] == '\0' || y[pos] == '\0' || x[pos] != y[pos]) {
            return false;
        }
    }
    return true;
}

/**
 * Read a line from stdin. At most buffer_size-1 characters + EOL will be read.
 * Resulting string is terminated by '\0', EOL character is not stored.
 * EOF can be expected on a non-empty line.
 * @param eof set to true if EOF is encountered
 * @return number of characters stored or buffer_size in the case of buffer
 *   overflow
 */
unsigned readline(char *buffer, unsigned buffer_size, bool *eof) {
    unsigned length = 0;
    for(int c = getchar(); c != '\n'; c = getchar()) {
        if(c == EOF) {
            *eof = true;
            break;
        }
        if(length == buffer_size) {
            break;
        }
        buffer[length++] = c;
    }
    buffer[length] = '\0';
    return length;
}


/**
 * Parse command line arguments in the extended (bonus) format.
 * @param argc number of arguments
 * @param argv arguments vector
 * @param level_pos position of the level argument in the vector
 * @param param_pos position of the param argument in the vector
 * @param print_stats if true, additional statistics will be printed
 * @return 0 on success and 1 if any error occurs
 */
int extended_args(int argc, char **argv, int *level_pos, int *param_pos, bool *print_stats) {
    // At most 5 user-supplied parameters + 1 program path
    if (argc > 6) {
        return 1;
    }

    // Iterate the whole list of parameters and identify LEVEL, PARAM and stats, if available
    for (int arg = 1; arg < argc; arg++) {
        // Level found
        if (string_equal(argv[arg], "-l")) {
            if (arg + 1 >= argc) {
                return 1;
            }
            // Duplicity
            if (*level_pos > 0) {
                return 1;
            }
            *level_pos = ++arg;
        // Param found
        } else if (string_equal(argv[arg], "-p")) {
            if (arg + 1 >= argc) {
                return 1;
            }
            // Duplicity
            if (*param_pos > 0) {
                return 1;
            }
            *param_pos = ++arg;
        // Stats found
        } else if (string_equal(argv[arg], "--stats")) {
            *print_stats = true;
        // Anything else is an error
        } else {
            return 1;
        }
    }
    return 0;
}


/**
 * Parse command line arguments in the basic format.
 * @param argc number of arguments
 * @param argv arguments vector
 * @param level_pos position of the level argument in the vector
 * @param param_pos position of the param argument in the vector
 * @param print_stats if true, additional statistics will be printed
 * @return 0 on success and 1 if any error occurs
 */
int basic_args(int argc, char **argv, int *level_pos, int *param_pos, bool *print_stats) {
    // assuming 2 or 3 command-line arguments
    if(argc < 3 || argc >= 5) {
        return 1;
    }
    // Level and param positions are fixed
    *level_pos = 1;
    *param_pos = 2;

    // Check if stats flag is present
    if(argc == 4) {
        if(!string_equal(argv[3], "--stats")) {
            return 1;
        }
        *print_stats = true;
    }
    return 0;
}


/* Core functions */

/** Print program usage. */
void print_usage() {
    fprintf(stderr, "usage: ./pwcheck [-l LEVEL] [-p PARAM] [--stats]\n");
}

/** Determine class of character c. */
enum CharacterClass char_classify(char c) {
    if(char_islower(c)) {
        return class_lower;
    }
    if(char_isupper(c)) {
        return class_upper;
    }
    if(char_isdigit(c)) {
        return class_digit;
    }
    if(char_isspecial(c)) {
        return class_special;
    }
    return class_other;
}

/** Classify all characters in a string. */
void string_classify(const char *str, unsigned *frequency) {
    for(unsigned pos = 0; str[pos] != '\0'; pos++) {
        frequency[char_classify(str[pos])]++;
    }
}

/** LEVEL 1: at least one small and one big letter. */
bool level_one(unsigned *frequency) {
    return frequency[class_lower] > 0 && frequency[class_upper] > 0;
}

/**LEVEL 2: encountered at least {@code required} character classes. */
bool level_two(unsigned *frequency, unsigned required) {
    unsigned classes_encountered = 0;
    for(enum CharacterClass c = class_lower; c <= class_special; c++) {
        if(frequency[c] > 0) {
            classes_encountered++;
        }
    }
    return classes_encountered >= required;
}

/**
 * LEVEL 3: no sequence of length at least {@code length_limit} of the same
 * character.
 */
bool level_three(const char *password, unsigned length_limit) {
    unsigned sequence;
    do {
        sequence = same_character_sequence(password);
        if(sequence >= length_limit) {
            return false;
        }
        password += sequence;
    } while(sequence > 0);
    return true;
}

/** LEVEL 4: no two (maybe overlapping) substrings of length_limit. */
bool level_four(const char *str, unsigned length_limit) {
    unsigned length_x = string_length(str);
    for(const char *x = str; length_x > length_limit; x++) {
        unsigned length_y = length_x-1;
        for(const char *y = x+1; length_y >= length_limit; y++) {
            if(string_equal_limited(x,y,length_limit)) {
                return false;
            }
            length_y--;
        }
        length_x--;
    }
    return true;
}

/** Identify security level of the provided password. */
unsigned password_level(const char *password, unsigned param) {

    // classify characters
    unsigned frequency[class_other+1];
    for(enum CharacterClass c = class_lower; c <= class_other; c++) {
        frequency[c] = 0;
    }
    string_classify(password, frequency);

    // identify unsatisfied security level
    if(!level_one(frequency)) {
        return 0;
    }
    if(!level_two(frequency, param)) {
        return 1;
    }
    if(!level_three(password, param)) {
        return 2;
    }
    if(!level_four(password, param)) {
        return 3;
    }
    return 4;
}

/**
 * Read passwords and filter those meeting security level.
 * @param print_stats if true, additional statistics will be printed
 * @return 0 on success and 1 if any error occurs
 */
int passwd_check(unsigned level, unsigned param, bool print_stats) {

    // prepare stats collection
    unsigned long lines_read = 0;
    bool characters[ASCII_CHARACTERS];
    for(unsigned c = 0; c < ASCII_CHARACTERS; c++) {
        characters[c] = false;
    }
    unsigned length_minimal;
    unsigned long length_total = 0;
    
    // read passwords from stdin
    bool eof = false;
    char line[MAX_STRING_LENGTH];
    while(!eof) {
        // read line
        unsigned line_length = readline(line, MAX_STRING_LENGTH, &eof);
        if(line_length == MAX_STRING_LENGTH) {
            fprintf(stderr, "line length exceeds the limit\n");
            return 1;
        }
        if(eof && line_length == 0) {
            // EOF on empty line
            break;
        }

        // process line
        unsigned line_level = password_level(line, param);
        if(line_level >= level) {
            printf("%s\n", line);
        }

        // update stats
        lines_read++;
        length_total += line_length;
        for(unsigned pos = 0; pos < line_length; pos++) {
            characters[(unsigned)line[pos]] = true;
        }
        if(lines_read == 1 || line_length < length_minimal) {
            length_minimal = line_length;
        }
    }
    // all passwords were processed

    if(print_stats) {
        // count different characters
        unsigned different_characters = 0;
        for(unsigned c = 0; c < ASCII_CHARACTERS; c++) {
            if(characters[c]) {
                different_characters++;
            }
        }
        // if at least one password was processed, the stats are valid

        double length_average = 0;
        if(lines_read == 0) {
            length_minimal = 0;
            length_average = 0;
        } else {
            length_average = (double)length_total / lines_read;
        }
        printf("Statistika:\n");
        printf("Ruznych znaku: %u\n", different_characters);
        printf("Minimalni delka: %u\n", length_minimal);
        printf("Prumerna delka: %.1f\n", length_average);
    }

    return 0;
}


/** Entry point. */
int main(int argc, char **argv) {

    // processing command-line arguments:
    int number;
    bool error_flag = false;
    unsigned level = 1;
    unsigned param = 1;
    bool print_stats = false;

    // Position of LEVEL and PARAM values
    int level_pos = -1;
    int param_pos = -1;

    // Determine if the we should use extended parsing or the basic one
    if (argc == 1 || string_equal(argv[1], "-l") || string_equal(argv[1], "-p") || 
            string_equal(argv[1], "--stats")) 
    {
        if (extended_args(argc, argv, &level_pos, &param_pos, &print_stats)) {
            print_usage();
            return 1;
        }
    } else {
        if (basic_args(argc, argv, &level_pos, &param_pos, &print_stats)) {
            print_usage();
            return 1;
        }
    }

    // process security level
    if (level_pos > 0) {
        number = string_to_unsigned(argv[level_pos], &error_flag);
        if(error_flag || number < 1 || number > 4) {
            fprintf(stderr, "error: invalid command-line argument (LEVEL)\n");
            return 1;
        }
        level = (unsigned) number;
    }

    // process security level
    if (param_pos > 0) {
        number = string_to_unsigned(argv[param_pos], &error_flag);
        if(error_flag || number < 1) {
            fprintf(stderr, "error: invalid command-line argument (LEVEL)\n");
            return 1;
        }
        param = (unsigned) number;
    }

    // execute
    return passwd_check(level, param, print_stats);
}